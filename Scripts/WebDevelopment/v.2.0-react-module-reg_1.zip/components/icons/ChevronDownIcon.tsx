
import React from 'react';

interface ChevronDownIconProps extends React.SVGProps<SVGSVGElement> {
  // no custom props
}

const ChevronDownIcon: React.FC<ChevronDownIconProps> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={1.5}
    stroke="currentColor"
    {...props}
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="m19.5 8.25-7.5 7.5-7.5-7.5"
    />
  </svg>
);

export default ChevronDownIcon;